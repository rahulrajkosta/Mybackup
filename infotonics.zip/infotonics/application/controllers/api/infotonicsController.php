<?php
defined('BASEPATH') or exit('No direct script access allowed');
require APPPATH . 'libraries/RestController.php';
require APPPATH . 'libraries/Format.php';
use chriskacerguis\RestServer\RestController;
class infotonicsController extends RestController
{
    public function __construct(){

        parent::__construct();
   
        // Load model
        $this->load->model('userModel');
     }

    public function user_get($id=0)
    {
       
        $user=$this->userModel->getRow($id);
        if(!empty($user))
        {
            $this->response($user,RestController::HTTP_OK);
        } 
        $this->response(['status'=>false,'message'=>"No Reford Found"],RestController::HTTP_NOT_FOUND);  
    }
    public function user_delete($id=0)
    {
       
        $user=$this->userModel->delete($id);
        if($user)
        {
            $this->response(['status'=>true,'message'=>"Recored Deleted"],RestController::HTTP_OK);
        } 
        $this->response(['status'=>false,'message'=>"No Reford Found"],RestController::HTTP_BAD_REQUEST );  
    }
    public function user_post()
    {
       $data['name']=$this->input->post('name');
       $data['mobile']=$this->input->post('mobile');
       $data['email']=$this->input->post('email');
        $user=$this->userModel->insert($data);
        if($user)
        {
            $this->response(['status'=>true,'message'=>"Recored Inserted Successfully"],RestController::HTTP_OK);
        } 
        $this->response(['status'=>false,'message'=>"Recored Not Inserted"],RestController::HTTP_FORBIDDEN );  
    }
    public function user_put($id)
    {
        
        $data['name']=$this->put('name');
        $data['mobile']=$this->put('mobile');
        $data['email']=$this->put('email');
        $user=$this->userModel->update($data,$id);
        if($user)
        {
            $this->response(['status'=>true,'message'=>"Recored Updated Successfully"],RestController::HTTP_OK);
        } 
        $this->response(['status'=>false,'message'=>"No Record Found"],RestController::HTTP_NOT_FOUND );  

        
       
    }
}
?>