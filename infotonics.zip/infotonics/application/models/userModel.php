<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class userModel extends CI_Model {

  function getRow($id=''){
    if(!empty($id))
    {
        return $this -> db-> select('*')-> where('id', $id)->get('infotonicsstudent')->row_array();
    }
    else{
        return $this -> db-> select('*')->get('infotonicsstudent')->result_array();
    }
  }
  function delete($id=''){
    
        $delete= $this->db->where('id',$id)->delete('infotonicsstudent');
        return $delete?true:false;
  }
  function insert($data){
   $insert= $this->db->insert('infotonicsstudent',$data);
   if($insert)
   {
    return $insert;
   }
  }
  function update($data,$id)
  {
    //print_r($data);

    $update= $this->db->where('id',$id)->update('infotonicsstudent',$data);
    if($update)
    {
        return $update;
    }
  }
}
?>