# Change Log

## Version 2.0.0

1. Adding `Eloquent` data source class to handle eloquent query


## Version 1.7.0

1. Detect secure connection to return correct url for assets.

## Version 1.6.0

1. Change README

## Version 1.5.0

1. Enhance assets url settings

## Version 1.0.0

1. Implement HandShake between KoolReport and Laravel so that KoolReport can access to database settings of Laravel
2. Create special LaravelDataSource to handle data source from Laravel.